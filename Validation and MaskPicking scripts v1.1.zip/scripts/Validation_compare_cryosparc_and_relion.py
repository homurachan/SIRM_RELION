#!/usr/bin/env python

import math, os, sys, random
try:
	from optparse import OptionParser
except:
	from optik import OptionParser

def main():
	(cryosparc_star,relion_star,VALUE,SYM_N,output_star) =  parse_command_line()
	asdfasdf = open(cryosparc_star, "r")
	instar_line=asdfasdf.readlines()
	asdf=open(relion_star,"r")
	oristar_line=asdf.readlines()
	name1=output_star+"_lessthan"+str(VALUE)+"_change_line.star"
	name2=output_star+"_morethan"+str(VALUE)+"_change_line.star"
	out=open(name1,"w")
	out2=open(name2,"w")
	o1=open(output_star,"w")
	relion30=1
	relion30=judge_relion30_or_relion31(inline=instar_line)
	print("Is relion3.0? = "+str(relion30))
	mline=-1
	if(relion30):
		mline=judge_mline0(inline=instar_line)
	else:
		#regard as relion3.1
		MLINE=judge_mline0(inline=instar_line)
		mline=judge_mline1(inline=instar_line,start=MLINE)
	if(mline<0):
		print("starfile error or this script cannot handle it. EXIT.")
		quit()
	print("cryosparc2relion mline = "+str(mline))
	
	for i in range(0,mline):
		out.write(instar_line[i])
		out2.write(instar_line[i])
		if (instar_line[i].split()):
			if str(instar_line[i].split()[0])=="_rlnAngleRot":
				Rot_index=int(instar_line[i].split('#')[1])-1
			if str(instar_line[i].split()[0])=="_rlnAngleTilt":
				Tilt_index=int(instar_line[i].split('#')[1])-1
			if str(instar_line[i].split()[0])=="_rlnImageName":
				IMG_index=int(instar_line[i].split('#')[1])-1
	relion30=1
	relion30=judge_relion30_or_relion31(inline=oristar_line)
	print("Is relion3.0? = "+str(relion30))
	mline2=-1
	if(relion30):
		mline2=judge_mline0(inline=oristar_line)
	else:
		#regard as relion3.1
		MLINE=judge_mline0(inline=oristar_line)
		mline2=judge_mline1(inline=oristar_line,start=MLINE)
	if(mline2<0):
		print("starfile error or this script cannot handle it. EXIT.")
		quit()
	print("original_relion mline = "+str(mline2))
	for i in range(0,mline2):
		if (oristar_line[i].split()):
			if str(oristar_line[i].split()[0])=="_rlnAngleRot":
				ori_Rot_index=int(oristar_line[i].split('#')[1])-1
			if str(oristar_line[i].split()[0])=="_rlnAngleTilt":
				ori_Tilt_index=int(oristar_line[i].split('#')[1])-1
			if str(oristar_line[i].split()[0])=="_rlnImageName":
				ori_IMG_index=int(oristar_line[i].split('#')[1])-1

	cryosparc2relion_serial=[]
	cryosparc2relion_imagename=[]
	cryosparc2relion_line=[]
	
	for i in range(mline,len(instar_line)):
		if(instar_line[i].split()):
			imagename=str(instar_line[i].split()[IMG_index])
			image_serial=int(imagename.split('@')[0])
			image_filename_tmp=cryosparc_filename(imagename)
			image_filename=""
			cryosparc2relion_serial.append([])
			cryosparc2relion_imagename.append([])
			cryosparc2relion_line.append([])
			for mm in range(0,len(image_filename_tmp)):
				image_filename+=image_filename_tmp[mm]
				image_filename+="_"
			cryosparc2relion_serial[len(cryosparc2relion_serial)-1]=image_serial
			cryosparc2relion_imagename[len(cryosparc2relion_imagename)-1]=image_filename
			cryosparc2relion_line[len(cryosparc2relion_line)-1]=i
			
	print("Finish reading part1")
	orirelion_serial=[]
	orirelion_imagename=[]
	orirelion_line=[]
	for i in range(mline2,len(oristar_line)):
		if(oristar_line[i].split()):
			imagename=str(oristar_line[i].split()[ori_IMG_index])
			image_filename_tmp=cryosparc_filename(imagename)
			image_serial=int(imagename.split('@')[0])

			image_filename=""
			orirelion_serial.append([])
			orirelion_imagename.append([])
			orirelion_line.append([])
			for mm in range(0,len(image_filename_tmp)):
				image_filename+=image_filename_tmp[mm]
				image_filename+="_"
			orirelion_serial[len(orirelion_serial)-1]=image_serial
			orirelion_imagename[len(orirelion_imagename)-1]=image_filename
			orirelion_line[len(orirelion_line)-1]=i		
	print("Finish reading part2")
	
	for i in range(0,len(cryosparc2relion_line)):
		N=len(orirelion_line)
		for j in range(0,N):
			if(cryosparc2relion_serial[i]==orirelion_serial[j]):
				if(cryosparc2relion_imagename[i]==orirelion_imagename[j]):
					
					rot=float(instar_line[cryosparc2relion_line[i]].split()[Rot_index])
					tilt=float(instar_line[cryosparc2relion_line[i]].split()[Tilt_index])
					MIN_VALUE=99999.0
					for N in range(0,SYM_N):
						rot1=rot+N*360.0/SYM_N
						v=VECTOR3D(rot1,tilt,0.0)
						
						ori_rot=float(oristar_line[orirelion_line[j]].split()[ori_Rot_index])
						ori_tilt=float(oristar_line[orirelion_line[j]].split()[ori_Tilt_index])
						v2=VECTOR3D(ori_rot,ori_tilt,0.0)
						Value=calculateAngularDistance(v[0],v[1],v[2],v2[0],v2[1],v2[2])
						if(Value<MIN_VALUE):
							MIN_VALUE=Value
					value=MIN_VALUE
					o1.write(str(orirelion_serial[j])+"@"+str(orirelion_imagename[j])+"\t"+str(value)+"\n")
					if(value<=VALUE):
						out.write(instar_line[cryosparc2relion_line[i]])
					if(value>VALUE):
						out2.write(instar_line[cryosparc2relion_line[i]])
					del orirelion_serial[j]
					del orirelion_imagename[j]
					del orirelion_line[j]

					break
	
					

	asdfasdf.close()
	asdf.close()
	o1.close()
	out.close()
	out2.close()

def parse_command_line():
	usage="%prog <input cryosparc star> <input relion star> <threshold value> <n for Cn symmetry> <output star>"
	parser = OptionParser(usage=usage, version="%1")
	
	if len(sys.argv)<6: 
		print("<input cryosparc star> <input relion star> <threshold value> <n for Cn symmetry> <output star>")
		sys.exit(-1)
	
	(options, args)=parser.parse_args()
	
	cryosparc_star = args[0]
	relion_star=(args[1])
	VALUE=float(args[2])
	SYM_N=int(args[3])
	output_star=args[4]
	return (cryosparc_star,relion_star,VALUE,SYM_N,output_star)
def cryosparc_filename(imagename):
	image_filename_tmp=(imagename.split('@')[1]).split('_')[1:]
	return (image_filename_tmp)
def relion_filename(imagename):
	image_filename_tmp=imagename.split('/')[-1]
	image_filename_tmp=image_filename_tmp.split('_')[0:]
	return (image_filename_tmp)
def SQR(x):
	y=float(x)
	return(y*y)
def Normal_vector(a,b,c):
	x=SQR(a)+SQR(b)+SQR(c)
	x=math.sqrt(x)
	if(x>1e-8):
		return(a/x,b/x,c/x)
	else:
		return(0.0,0.0,0.0)
def Euler_angles2direction(alpha, beta):

	alpha = DEG2RAD(alpha)
	beta = DEG2RAD(beta)
	v=[]
	for i in range(0,3):
		v.append([])
	ca = math.cos(alpha)
	cb = math.cos(beta)
	sa = math.sin(alpha)
	sb = math.sin(beta)
	sc = sb * ca
	ss = sb * sa

	v[0]= sc
	v[1] = ss
	v[2] = cb
	return v

def DEG2RAD(x):
	return(x/180.0*3.14159265359)
def Euler_angles2matrix(alpha, beta, gamma):
	alpha = DEG2RAD(alpha)
	beta  = DEG2RAD(beta)
	gamma = DEG2RAD(gamma)
	ca =  math.cos(alpha)
	cb =  math.cos(beta)
	cg =  math.cos(gamma)
	sa =  math.sin(alpha)
	sb =  math.sin(beta)
	sg =  math.sin(gamma)
	cc =  cb * ca
	cs =  cb * sa
	sc =  sb * ca
	ss =  sb * sa
	A=[]
	for i in range(0,3):
		A.append([])
		for j in range(0,3):
			A[i].append([])
	A[0][0] =  cg * cc - sg * sa
	A[0][1] =  cg * cs + sg * ca
	A[0][2] = -cg * sb
	A[1][0] = -sg * cc - cg * sa
	A[1][1] = -sg * cs + cg * ca
	A[1][2] = sg * sb
	A[2][0] =  sc
	A[2][1] =  ss
	A[2][2] = cb
	return A

def calculateAngularDistance(rot1, tilt1,psi1,rot2, tilt2,psi2):

#	direction1=Euler_angles2direction(alpha=rot1, beta=tilt1)
#	direction2=Euler_angles2direction(alpha=rot2, beta=tilt2)
	min_axes_dist = 3600.0

	E1=Euler_angles2matrix(alpha=rot1, beta=tilt1, gamma=psi1)
	E2=Euler_angles2matrix(alpha=rot2, beta=tilt2, gamma=psi2)
	v1=[]
	v2=[]
	axes_dist = 0;
	for i in range(0,3):
		v1=E1[i]
		v2=E2[i]
		axes_dist += math.acos(CLIP(a=dotProduct(v1, v2),b=-1., c=1.))*180.0/3.14159265359
	axes_dist=axes_dist/3.0
	if (axes_dist < min_axes_dist):
		min_axes_dist = axes_dist
	return min_axes_dist
	
def CLIP(a,b,c):
	if(float(a)<float(b)):
		return float(b)
	else:
		if(float(a)>float(c)):
			return float(c)
		return float(a)
def dotProduct(v1,v2):
	if(len(v1)!=len(v2)):
		return -9999999.0
	sum=0.0
	for i in range(0,len(v1)):
		sum+=float(v1[i])*float(v2[i])
	return sum
def calc_mean(PDF):
	X=len(PDF)
	SUM=0.0
	for i in range(0,X):	
		SUM+=float(PDF[i])
	SUM=SUM/X
	return SUM
def calc_sigma(PDF):
	X=len(PDF)
	SUM=0.0
	SUM_SQR=0.0
	for i in range(0,X):	
		SUM+=float(PDF[i])
		SUM_SQR+=SQR(float(PDF[i]))
	SUM_SQR=SUM_SQR/X
	SUM=SUM/X
	RETURN=math.sqrt(SUM_SQR-SQR(SUM))
	return RETURN
def calc_max(PDF):
	X=len(PDF)
	Y=-999999999.0
	for i in range(0,X):
		if(float(PDF[i])>Y):
			Y=float(PDF[i])
	return Y
def calc_min(PDF):
	X=len(PDF)
	Y=999999999.0
	for i in range(0,X):
		if(float(PDF[i])<Y):
			Y=float(PDF[i])
	return Y
def del_member(x,n):
	line=[]
	C_line=0
	for i in range(0,len(x)):		
		if (i==n):
			continue
		line.append([])
		line[C_line]=x[i]
		C_line+=1
	return line
def ACOSD(x):
	return(math.acos((x)) * 180./3.1415927)
def Euler_direction2angles(v):
	rot = math.degrees(math.atan2(v[1], v[0]))
	tilt = math.degrees(math.acos(v[2]))
	if ( (math.fabs(tilt) < 0.001) or (math.fabs(tilt - 180.) < 0.001) ):
		rot = 0.
	return (rot,tilt)
def VECTOR3D(x,y,z):
	v=[]
	for i in range(0,3):
		v.append([])
	v[0]=x
	v[1]=y
	v[2]=z
	return (v)
def VECTOR2D(x,y):
	v=[]
	for i in range(0,2):
		v.append([])
	v[0]=x
	v[1]=y
	return (v)	
def judge_relion30_or_relion31(inline):
	trys=3
	RELION30=1
	for i in range (0,trys):
		
		if(inline[i].split()):
			if(len(inline[i].split())>=2):
				if(inline[i].split()[0][0]=="#" and int(str(inline[i].split()[2]))>30000):
					RELION30=0
					break
	return RELION30
def judge_mline0(inline):
	trys=60
	intarget=-1
	for i in range (0,trys):
		if(inline[i].split()):
			if(inline[i].split()[0][0]!="_"):
				if(intarget==1):
					return i
					break
				else:
					continue
			if(inline[i].split()[0][0]=="_"):
				intarget=1
def judge_mline1(inline,start):
	trys=70
	intarget=-1
	for i in range (start,trys):
		if(inline[i].split()):
			if(inline[i].split()[0][0]!="_"):
				if(intarget==1):
					return i
					break
				else:
					continue
			if(inline[i].split()[0][0]=="_"):
				intarget=1		
if __name__== "__main__":
	main()


			
