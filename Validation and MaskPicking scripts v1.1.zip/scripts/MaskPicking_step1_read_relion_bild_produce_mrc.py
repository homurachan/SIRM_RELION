#!/usr/bin/env python
import mrcfile
import numpy as np
import math,os,sys
try:
	from optparse import OptionParser
except:
	from optik import OptionParser

def main():
	(bild_name,angle_step_size,mrc_radius,output) =  parse_command_line()
	bild_file=open(bild_name,"r")
	line_bild_file=bild_file.readlines()
	width=0.0
	R=0.0
	scale_RP=1.0e5
	SIZE=int(round(2.0*mrc_radius))+4
	example_data = np.zeros((SIZE*SIZE*SIZE,), dtype=np.single).reshape(SIZE,SIZE,SIZE)
#	debug_=open("debugxxxx.bild","w")
	for i in range(0,len(line_bild_file)):
		if(line_bild_file[i].split()):
			if(str(line_bild_file[i].split()[0])==".cylinder"):
				width=float(str(line_bild_file[i].split()[7]))
				R=width/0.5/3.1415927/(angle_step_size/360.0)
				break
	print(("R="+str(R)))
	offset=R
	for i in range(0,len(line_bild_file)):
		if(line_bild_file[i].split()):
			if(str(line_bild_file[i].split()[0])==".cylinder"):
				x=float(str(line_bild_file[i].split()[1]))
				xp=float(str(line_bild_file[i].split()[4]))
				y=float(str(line_bild_file[i].split()[2]))
				yp=float(str(line_bild_file[i].split()[5]))
				z=float(str(line_bild_file[i].split()[3]))
				zp=float(str(line_bild_file[i].split()[6]))
				#xp-x=(Rp-R)*XX(v)
				Rp=math.sqrt(SQR(xp-x)+SQR(yp-y)+SQR(zp-z))+R
				vx=(xp-x)/(Rp-R)
				vy=(yp-y)/(Rp-R)
				vz=(zp-z)/(Rp-R)
				relative_Rp=(Rp-R)/R
				(nvx,nvy,nvz)=Normal_vector(vx,vy,vz)
				POSI_X=int(round(mrc_radius*nvx)+SIZE/2)
				POSI_Y=int(round(mrc_radius*nvy)+SIZE/2)
				POSI_Z=int(round(mrc_radius*nvz)+SIZE/2)
				if(POSI_X>=0 and POSI_X<SIZE and POSI_Y>=0 and POSI_Y<SIZE and POSI_Z>=0 and POSI_Z<SIZE):
				#	example_data[POSI_X,POSI_Y,POSI_Z]+=scale_RP*relative_Rp
					example_data[POSI_Z,POSI_Y,POSI_X]+=scale_RP*relative_Rp
	with mrcfile.new(output,overwrite=True) as mrc:
		mrc.set_data(example_data)
	bild_file.close()
	
def parse_command_line():
	usage="%prog <input bild> <Angle step size in degree> <output mrc radius in pixel> <output mrc file>"
	parser = OptionParser(usage=usage, version="%1")
	
	if len(sys.argv)<4: 
		print("<input bild> <Angle step size in degree> <output mrc radius in pixel> <output mrc file>")
		sys.exit(-1)
	
	(options, args)=parser.parse_args()
	bild_name=str(args[0])
	angle_step_size=float(args[1])
	mrc_radius=float(args[2])
	output=str(args[3])
	return (bild_name,angle_step_size,mrc_radius,output)
def SQR(x):
	y=float(x)
	return(y*y)
def Normal_vector(a,b,c):
	x=SQR(a)+SQR(b)+SQR(c)
	x=math.sqrt(x)
	if(x>1e-8):
		return(a/x,b/x,c/x)
	else:
		return(0.0,0.0,0.0)
def Euler_angles2direction(alpha, beta):

	alpha = DEG2RAD(alpha)
	beta = DEG2RAD(beta)
	v=[]
	for i in range(0,3):
		v.append([])
	ca = math.cos(alpha)
	cb = math.cos(beta)
	sa = math.sin(alpha)
	sb = math.sin(beta)
	sc = sb * ca
	ss = sb * sa

	v[0]= sc
	v[1] = ss
	v[2] = cb
	return v

def DEG2RAD(x):
	return(x/180.0*3.14159265359)
def Euler_angles2matrix(alpha, beta, gamma):
	alpha = DEG2RAD(alpha)
	beta  = DEG2RAD(beta)
	gamma = DEG2RAD(gamma)
	ca =  math.cos(alpha)
	cb =  math.cos(beta)
	cg =  math.cos(gamma)
	sa =  math.sin(alpha)
	sb =  math.sin(beta)
	sg =  math.sin(gamma)
	cc =  cb * ca
	cs =  cb * sa
	sc =  sb * ca
	ss =  sb * sa
	A=[]
	for i in range(0,3):
		A.append([])
		for j in range(0,3):
			A[i].append([])
	A[0][0] =  cg * cc - sg * sa
	A[0][1] =  cg * cs + sg * ca
	A[0][2] = -cg * sb
	A[1][0] = -sg * cc - cg * sa
	A[1][1] = -sg * cs + cg * ca
	A[1][2] = sg * sb
	A[2][0] =  sc
	A[2][1] =  ss
	A[2][2] = cb
	return A

def calculateAngularDistance(rot1, tilt1,psi1,rot2, tilt2,psi2):

#	direction1=Euler_angles2direction(alpha=rot1, beta=tilt1)
#	direction2=Euler_angles2direction(alpha=rot2, beta=tilt2)
	min_axes_dist = 3600.0

	E1=Euler_angles2matrix(alpha=rot1, beta=tilt1, gamma=psi1)
	E2=Euler_angles2matrix(alpha=rot2, beta=tilt2, gamma=psi2)
	v1=[]
	v2=[]
	axes_dist = 0;
	for i in range(0,3):
		v1=E1[i]
		v2=E2[i]
		axes_dist += math.acos(CLIP(a=dotProduct(v1, v2),b=-1., c=1.))*180.0/3.14159265359
	axes_dist=axes_dist/3.0
	if (axes_dist < min_axes_dist):
		min_axes_dist = axes_dist
	return min_axes_dist
	
def CLIP(a,b,c):
	if(float(a)<float(b)):
		return float(b)
	else:
		if(float(a)>float(c)):
			return float(c)
		return float(a)
def dotProduct(v1,v2):
	if(len(v1)!=len(v2)):
		return -9999999.0
	sum=0.0
	for i in range(0,len(v1)):
		sum+=float(v1[i])*float(v2[i])
	return sum
def calc_mean(PDF):
	X=len(PDF)
	SUM=0.0
	for i in range(0,X):	
		SUM+=float(PDF[i])
	SUM=SUM/X
	return SUM
def calc_sigma(PDF):
	X=len(PDF)
	SUM=0.0
	SUM_SQR=0.0
	for i in range(0,X):	
		SUM+=float(PDF[i])
		SUM_SQR+=SQR(float(PDF[i]))
	SUM_SQR=SUM_SQR/X
	SUM=SUM/X
	RETURN=math.sqrt(SUM_SQR-SQR(SUM))
	return RETURN
def calc_max(PDF):
	X=len(PDF)
	Y=-999999999.0
	for i in range(0,X):
		if(float(PDF[i])>Y):
			Y=float(PDF[i])
	return Y
def calc_min(PDF):
	X=len(PDF)
	Y=999999999.0
	for i in range(0,X):
		if(float(PDF[i])<Y):
			Y=float(PDF[i])
	return Y
def del_member(x,n):
	line=[]
	C_line=0
	for i in range(0,len(x)):		
		if (i==n):
			continue
		line.append([])
		line[C_line]=x[i]
		C_line+=1
	return line
def ACOSD(x):
	return(math.acos((x)) * 180./3.1415927)
def Euler_direction2angles(v):
	rot = math.degrees(math.atan2(v[1], v[0]))
	tilt = math.degrees(math.acos(v[2]))
	if ( (math.fabs(tilt) < 0.001) or (math.fabs(tilt - 180.) < 0.001) ):
		rot = 0.
	return (rot,tilt)
if __name__== "__main__":
	main()
